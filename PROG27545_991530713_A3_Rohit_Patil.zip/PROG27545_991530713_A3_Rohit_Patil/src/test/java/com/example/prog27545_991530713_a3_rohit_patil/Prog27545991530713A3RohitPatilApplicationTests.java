package com.example.prog27545_991530713_a3_rohit_patil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prog27545991530713A3RohitPatilApplicationTests {

    @Test
    void contextLoads() {
    }

}
