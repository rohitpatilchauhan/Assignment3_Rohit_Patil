package com.example.prog27545_991530713_a3_rohit_patil.controller;

import com.example.prog27545_991530713_a3_rohit_patil.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final OrderService orderService;

    public AdminController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public String adminDashboard(Model model) {
        model.addAttribute("allOrders", orderService.getAllOrders());
        model.addAttribute("totalSales", orderService.getTotalSales());
        return "admin";
    }
}
