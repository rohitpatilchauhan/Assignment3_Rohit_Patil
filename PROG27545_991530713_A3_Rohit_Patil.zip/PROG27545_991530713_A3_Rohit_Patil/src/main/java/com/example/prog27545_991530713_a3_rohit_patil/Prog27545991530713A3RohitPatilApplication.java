package com.example.prog27545_991530713_a3_rohit_patil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prog27545991530713A3RohitPatilApplication {
    public static void main(String[] args) {
        SpringApplication.run(Prog27545991530713A3RohitPatilApplication.class, args);
    }
}
