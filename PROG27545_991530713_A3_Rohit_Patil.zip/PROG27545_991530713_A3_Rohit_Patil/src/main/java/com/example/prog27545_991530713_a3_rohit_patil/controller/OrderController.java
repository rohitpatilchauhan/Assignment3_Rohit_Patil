package com.example.prog27545_991530713_a3_rohit_patil.controller;

import com.example.prog27545_991530713_a3_rohit_patil.model.DeviceOrder;
import com.example.prog27545_991530713_a3_rohit_patil.service.OrderService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/order")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public String showOrderForm(Model model) {
        model.addAttribute("order", new DeviceOrder());
        return "order";
    }

    @PostMapping
    public String processOrder(@ModelAttribute DeviceOrder order, Authentication authentication) {
        String email = authentication.getName();
        orderService.saveOrder(order, email);
        return "redirect:/receipt";
    }

    @GetMapping("/history")
    public String orderHistory(Authentication authentication, Model model) {
        String email = authentication.getName();
        model.addAttribute("orders", orderService.getOrdersByUser(email));
        return "order-history"; // Maps to order-history.html (Thymeleaf template)
    }
}
