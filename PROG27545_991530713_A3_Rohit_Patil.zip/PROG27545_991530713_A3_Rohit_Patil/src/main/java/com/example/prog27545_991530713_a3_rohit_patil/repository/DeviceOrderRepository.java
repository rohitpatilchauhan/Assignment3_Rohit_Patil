package com.example.prog27545_991530713_a3_rohit_patil.repository;

import com.example.prog27545_991530713_a3_rohit_patil.model.DeviceOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface DeviceOrderRepository extends JpaRepository<DeviceOrder, Long> {

    List<DeviceOrder> findByUser_Email(String email);

    @Query("SELECT COALESCE(SUM(o.quantity * CASE WHEN o.deviceType = 'Android' THEN 900 ELSE 950 END), 0) FROM DeviceOrder o")
    BigDecimal getTotalSales();
}
