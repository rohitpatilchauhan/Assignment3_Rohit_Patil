package com.example.prog27545_991530713_a3_rohit_patil.service;

import com.example.prog27545_991530713_a3_rohit_patil.model.DeviceOrder;
import com.example.prog27545_991530713_a3_rohit_patil.repository.DeviceOrderRepository;
import com.example.prog27545_991530713_a3_rohit_patil.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {

    private final DeviceOrderRepository orderRepository;
    private final UserRepository userRepository;

    public OrderService(DeviceOrderRepository orderRepository, UserRepository userRepository) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
    }

    public void saveOrder(DeviceOrder order, String email) {
        var user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        order.setUser(user);
        orderRepository.save(order);
    }

    public List<DeviceOrder> getOrdersByUser(String email) {
        return orderRepository.findByUser_Email(email);
    }

    public List<DeviceOrder> getAllOrders() {
        return orderRepository.findAll();
    }

    public BigDecimal getTotalSales() {
        return orderRepository.getTotalSales();
    }
}
